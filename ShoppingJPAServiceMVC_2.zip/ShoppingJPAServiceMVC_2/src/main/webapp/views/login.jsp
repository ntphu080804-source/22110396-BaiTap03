<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
	<%@ taglib prefix="c" uri="jakarta.tags.core" %>
		<!DOCTYPE html>
		<html>

		<head>
			<meta charset="UTF-8">
			<title>Đăng nhập hệ thống</title>
			<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
		</head>

		<body class="bg-light d-flex align-items-center" style="height: 100vh;">
			<div class="container">
				<div class="card mx-auto shadow-sm" style="max-width: 420px;">
					<div class="card-header bg-primary text-white text-center">
						<h4 class="mb-0">ĐĂNG NHẬP</h4>
					</div>
					<div class="card-body">
						<c:if test="${not empty alert}">
							<div class="alert alert-danger">${alert}</div>
						</c:if>
						<c:if test="${not empty message}">
							<div class="alert alert-success">${message}</div>
						</c:if>
						<form action="<c:url value='/login'/>" method="post">
							<div class="mb-3">
								<label class="form-label">Tài khoản</label>
								<input type="text" name="username" class="form-control" value="${cookie.username.value}"
									required>
							</div>
							<div class="mb-3">
								<label class="form-label">Mật khẩu</label>
								<input type="password" name="password" class="form-control" required>
							</div>
							<div class="d-flex justify-content-between mb-3">
								<div class="form-check">
									<input type="checkbox" name="remember" class="form-check-input" id="remember">
									<label class="form-check-label" for="remember">Nhớ tôi</label>
								</div>
								<a href="<c:url value='/forgot-password'/>">Quên mật khẩu?</a>
							</div>
							<button type="submit" class="btn btn-primary w-100">Đăng nhập</button>
						</form>
						<div class="text-center mt-3">
							<a href="<c:url value='/register'/>">Chưa có tài khoản? Đăng ký ngay</a>
						</div>
					</div>
				</div>
			</div>
		</body>

		</html>