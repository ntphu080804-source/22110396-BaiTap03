<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
	<%@ taglib prefix="c" uri="jakarta.tags.core" %>
		<!DOCTYPE html>
		<html>

		<head>
			<meta charset="UTF-8">
			<title>Danh sách Video của tôi</title>
			<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
		</head>

		<body class="container py-4">
			<div class="d-flex justify-content-between align-items-center mb-4 border-bottom pb-2">
				<h3 class="text-primary">Video Của Tôi (${sessionScope.account.fullName})</h3>
				<div>
					<a href="<c:url value='/home'/>" class="btn btn-secondary btn-sm">Trang chủ</a>
					<c:if test="${sessionScope.account.roleid == 1}">
						<a href="<c:url value='/admin/videos'/>" class="btn btn-warning btn-sm">Quản trị Admin</a>
					</c:if>
					<a href="<c:url value='/logout'/>" class="btn btn-danger btn-sm">Đăng xuất</a>
				</div>
			</div>

			<div class="row row-cols-1 row-cols-md-3 g-4 mb-4">
				<c:forEach items="${videos}" var="v">
					<div class="col">
						<div class="card h-100 shadow-sm">
							<c:choose>
								<c:when test="${not empty v.poster && v.poster.startsWith('http')}">
									<c:set var="posterUrl" value="${v.poster}" />
								</c:when>
								<c:otherwise>
									<c:url var="posterUrl" value="/image?fname=${v.poster}" />
								</c:otherwise>
							</c:choose>
							<img src="${posterUrl}" class="card-img-top" style="height: 180px; object-fit: cover;">
							<div class="card-body">
								<h5 class="card-title">
									<a href="<c:url value='/video/detail?id=${v.videoId}'/>"
										class="text-decoration-none">
										${v.title}
									</a>
								</h5>
								<p class="card-text text-muted small">
									Lượt xem: ${v.views} | Danh mục: ${v.category.categoryname}
								</p>
							</div>
						</div>
					</div>
				</c:forEach>
			</div>

			<!-- Thanh phân trang (6 sản phẩm / trang) -->
			<c:if test="${totalPages > 1}">
				<nav>
					<ul class="pagination justify-content-center">
						<c:forEach begin="1" end="${totalPages}" var="i">
							<li class="page-item ${currentPage == i ? 'active' : ''}">
								<a class="page-link" href="<c:url value='/video?page=${i}'/>">${i}</a>
							</li>
						</c:forEach>
					</ul>
				</nav>
			</c:if>
		</body>

		</html>