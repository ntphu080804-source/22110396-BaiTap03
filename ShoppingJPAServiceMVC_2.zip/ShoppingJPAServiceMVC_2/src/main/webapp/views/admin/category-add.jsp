<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
	<%@ taglib prefix="c" uri="jakarta.tags.core" %>
		<!DOCTYPE html>
		<html>

		<head>
			<meta charset="UTF-8">
			<title>Thêm Category</title>
			<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
		</head>

		<body class="container py-4">
			<div class="card mx-auto" style="max-width: 500px;">
				<div class="card-header bg-success text-white">
					<h5 class="mb-0">Thêm Category Mới</h5>
				</div>
				<div class="card-body">
					<form action="<c:url value='/admin/category/insert'/>" method="post" enctype="multipart/form-data">
						<div class="mb-3">
							<label class="form-label">Category name:</label>
							<input type="text" name="categoryname" class="form-control" required>
						</div>
						<div class="mb-3">
							<label class="form-label">Link images (URL):</label>
							<input type="text" name="images" class="form-control" placeholder="https://...">
						</div>
						<div class="mb-3">
							<label class="form-label">Hoặc Upload images:</label>
							<input type="file" name="images1" class="form-control">
						</div>
						<div class="mb-3">
							<label class="form-label d-block">Status:</label>
							<input type="radio" id="ston" name="status" value="1" checked> <label for="ston"
								class="me-3">Hoạt động</label>
							<input type="radio" id="stoff" name="status" value="0"> <label for="stoff">Khóa</label>
						</div>
						<button type="submit" class="btn btn-success">Insert</button>
						<a href="<c:url value='/admin/categories'/>" class="btn btn-secondary">Quay lại</a>
					</form>
				</div>
			</div>
		</body>

		</html>