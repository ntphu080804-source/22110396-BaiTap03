<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
	<%@ taglib prefix="c" uri="jakarta.tags.core" %>
		<!DOCTYPE html>
		<html>

		<head>
			<meta charset="UTF-8">
			<title>Admin - Quản lý Videos</title>
			<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
		</head>

		<body class="container py-4">
			<nav class="navbar navbar-expand-lg navbar-dark bg-primary rounded px-3 mb-4">
				<a class="navbar-brand fw-bold" href="<c:url value='/admin/categories'/>">ADMIN PANEL</a>
				<div class="navbar-nav">
					<a class="nav-link" href="<c:url value='/admin/categories'/>">Quản lý Danh mục</a>
					<a class="nav-link active fw-bold" href="<c:url value='/admin/videos'/>">Quản lý Videos</a>
					<a class="nav-link" href="<c:url value='/admin/mail-config'/>">Cấu hình Email OTP</a>
					<a class="nav-link" href="<c:url value='/home'/>">Xem Trang chủ</a>
				</div>
				<div class="ms-auto text-white">
					<span class="me-3">Admin: <strong>${sessionScope.account.fullName}</strong></span>
					<a href="<c:url value='/logout'/>" class="btn btn-danger btn-sm">Đăng xuất</a>
				</div>
			</nav>

			<div class="d-flex justify-content-between align-items-center mb-3">
				<h3 class="text-primary">Quản Lý Videos Hệ Thống</h3>
				<a href="<c:url value='/admin/video/add'/>" class="btn btn-success">+ Thêm Video Mới</a>
			</div>

			<table class="table table-bordered table-hover align-middle">
				<thead class="table-light">
					<tr>
						<th>Mã Video</th>
						<th>Poster</th>
						<th>Tiêu đề</th>
						<th>Danh mục</th>
						<th>Người đăng</th>
						<th>Lượt xem</th>
						<th>Trạng thái</th>
						<th>Thao tác</th>
					</tr>
				</thead>
				<tbody>
					<c:forEach items="${videos}" var="v">
						<tr>
							<td>${v.videoId}</td>
							<td>
								<c:choose>
									<c:when test="${not empty v.poster && v.poster.startsWith('http')}">
										<c:set var="pUrl" value="${v.poster}" />
									</c:when>
									<c:otherwise>
										<c:url var="pUrl" value="/image?fname=${v.poster}" />
									</c:otherwise>
								</c:choose>
								<img src="${pUrl}" width="120" height="70" style="object-fit: cover;">
							</td>
							<td><a href="<c:url value='/video/detail?id=${v.videoId}'/>"
									class="fw-bold text-decoration-none">${v.title}</a></td>
							<td>${v.category.categoryname}</td>
							<td>${v.user.fullName}</td>
							<td>${v.views}</td>
							<td>
								<c:if test="${v.active == 1}"><span class="badge bg-success">Hiển thị</span></c:if>
								<c:if test="${v.active != 1}"><span class="badge bg-secondary">Ẩn</span></c:if>
							</td>
							<td>
								<a href="<c:url value='/admin/video/edit?id=${v.videoId}'/>"
									class="btn btn-sm btn-primary">Sửa</a>
								<a href="<c:url value='/admin/video/delete?id=${v.videoId}'/>"
									onclick="return confirm('Xóa video này?')" class="btn btn-sm btn-danger">Xóa</a>
							</td>
						</tr>
					</c:forEach>
				</tbody>
			</table>
		</body>

		</html>