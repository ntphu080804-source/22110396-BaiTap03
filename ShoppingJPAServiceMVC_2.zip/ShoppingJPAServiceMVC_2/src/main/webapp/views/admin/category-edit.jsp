<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
	<%@ taglib prefix="c" uri="jakarta.tags.core" %>
		<!DOCTYPE html>
		<html>

		<head>
			<meta charset="UTF-8">
			<title>Sửa Category</title>
			<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
		</head>

		<body class="container py-4">
			<div class="card mx-auto" style="max-width: 500px;">
				<div class="card-header bg-primary text-white">
					<h5 class="mb-0">Cập Nhật Category</h5>
				</div>
				<div class="card-body">
					<form action="<c:url value='/admin/category/update'/>" method="post" enctype="multipart/form-data">
						<input type="hidden" name="categoryid" value="${cate.categoryid}">
						<div class="mb-3">
							<label class="form-label">Category name:</label>
							<input type="text" name="categoryname" class="form-control" value="${cate.categoryname}"
								required>
						</div>
						<div class="mb-3">
							<label class="form-label">Link images:</label>
							<input type="text" name="images" class="form-control" value="${cate.images}">
						</div>
						<div class="mb-3">
							<c:choose>
								<c:when test="${not empty cate.images && cate.images.startsWith('http')}">
									<c:url value="${cate.images}" var="imgUrl" />
								</c:when>
								<c:otherwise>
									<c:url value="/image?fname=${cate.images}" var="imgUrl" />
								</c:otherwise>
							</c:choose>
							<img height="120" width="160" src="${imgUrl}" class="d-block mb-2 border" />
							<label class="form-label">Upload images mới:</label>
							<input type="file" name="images1" class="form-control">
						</div>
						<div class="mb-3">
							<label class="form-label d-block">Status:</label>
							<input type="radio" id="ston" name="status" value="1" ${cate.status==1?'checked':''}> <label
								for="ston" class="me-3">Hoạt động</label>
							<input type="radio" id="stoff" name="status" value="0" ${cate.status!=1?'checked':''}>
							<label for="stoff">Khóa</label>
						</div>
						<button type="submit" class="btn btn-primary">Update</button>
						<a href="<c:url value='/admin/categories'/>" class="btn btn-secondary">Quay lại</a>
					</form>
				</div>
			</div>
		</body>

		</html>