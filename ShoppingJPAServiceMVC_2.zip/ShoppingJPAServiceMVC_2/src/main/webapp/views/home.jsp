<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
	<%@ taglib prefix="c" uri="jakarta.tags.core" %>
		<!DOCTYPE html>
		<html>

		<head>
			<meta charset="UTF-8">
			<title>Trang chủ - 10 Video Mới Nhất</title>
			<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
		</head>

		<body class="container py-4">
			<nav class="navbar navbar-expand-lg navbar-dark bg-dark rounded px-3 mb-4">
				<a class="navbar-brand fw-bold" href="<c:url value='/home'/>">VIDEO PORTAL</a>
				<div class="ms-auto d-flex align-items-center text-white">
					<a href="<c:url value='/video'/>" class="btn btn-outline-light btn-sm me-2">Video của tôi
						(/video)</a>
					<c:if test="${sessionScope.account.roleid == 1}">
						<a href="<c:url value='/admin/videos'/>" class="btn btn-warning btn-sm me-3">Quản lý Videos
							(Admin)</a>
					</c:if>
					<c:choose>
						<c:when test="${not empty sessionScope.account}">
							<span class="me-3">Chào, <strong>${sessionScope.account.fullName}</strong></span>
							<a href="<c:url value='/logout'/>" class="btn btn-danger btn-sm">Đăng xuất</a>
						</c:when>
						<c:otherwise>
							<a href="<c:url value='/login'/>" class="btn btn-primary btn-sm">Đăng nhập</a>
						</c:otherwise>
					</c:choose>
				</div>
			</nav>

			<h4 class="mb-3 text-primary border-bottom pb-2">10 VIDEO MỚI NHẤT</h4>
			<div class="row row-cols-1 row-cols-md-3 g-4">
				<c:forEach items="${top10Videos}" var="v">
					<div class="col">
						<div class="card h-100 shadow-sm">
							<c:choose>
								<c:when test="${not empty v.poster && v.poster.startsWith('http')}">
									<c:set var="posterUrl" value="${v.poster}" />
								</c:when>
								<c:otherwise>
									<c:url var="posterUrl" value="/image?fname=${v.poster}" />
								</c:otherwise>
							</c:choose>
							<img src="${posterUrl}" class="card-img-top" style="height: 180px; object-fit: cover;">
							<div class="card-body">
								<h5 class="card-title">
									<a href="<c:url value='/video/detail?id=${v.videoId}'/>"
										class="text-decoration-none">
										${v.title}
									</a>
								</h5>
								<p class="card-text text-muted small">
									Người đăng: <strong>${v.user.fullName}</strong> | Lượt xem: ${v.views}
								</p>
							</div>
						</div>
					</div>
				</c:forEach>
			</div>
		</body>

		</html>