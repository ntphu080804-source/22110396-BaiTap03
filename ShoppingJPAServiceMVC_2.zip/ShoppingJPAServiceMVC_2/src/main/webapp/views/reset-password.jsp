<!-- views/reset-password.jsp -->
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
	<%@ taglib prefix="c" uri="jakarta.tags.core" %>
		<!DOCTYPE html>
		<html>

		<head>
			<meta charset="UTF-8">
			<title>Đặt lại mật khẩu</title>
			<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
		</head>

		<body class="bg-light d-flex align-items-center" style="height: 100vh;">
			<div class="container">
				<div class="card mx-auto shadow-sm" style="max-width: 400px;">
					<div class="card-header bg-success text-white text-center">
						<h5 class="mb-0">ĐẶT LẠI MẬT KHẨU</h5>
					</div>
					<div class="card-body">
						<p class="text-muted">Mã OTP đã gửi đến: <strong>${sessionScope.resetEmail}</strong></p>
						<c:if test="${not empty alert}">
							<div class="alert alert-danger">${alert}</div>
						</c:if>
						<form action="<c:url value='/reset-password'/>" method="post">
							<div class="mb-3">
								<label class="form-label">Mã OTP xác nhận</label>
								<input type="text" name="otp" class="form-control" maxlength="6" required>
							</div>
							<div class="mb-3">
								<label class="form-label">Mật khẩu mới</label>
								<input type="password" name="newPassword" class="form-control" required>
							</div>
							<button type="submit" class="btn btn-success w-100">Đổi mật khẩu</button>
						</form>
					</div>
				</div>
			</div>
		</body>

		</html>