package vn.iotstar.entity;

import java.io.Serializable;
import java.sql.Date;
import java.util.List;
import jakarta.persistence.*;

@Entity
@Table(name = "Users")
@NamedQuery(name = "User.findAll", query = "SELECT u FROM User u")
public class User implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;

	@Column(name = "email", columnDefinition = "NVARCHAR(150) NOT NULL", unique = true)
	private String email;

	@Column(name = "username", columnDefinition = "NVARCHAR(50) NOT NULL", unique = true)
	private String userName;

	@Column(name = "fullname", columnDefinition = "NVARCHAR(100) NULL")
	private String fullName;

	@Column(name = "password", columnDefinition = "NVARCHAR(255) NOT NULL")
	private String password;

	@Column(name = "avatar", columnDefinition = "NVARCHAR(255) NULL")
	private String avatar;

	@Column(name = "roleid")
	private Integer roleid;

	@Column(name = "phone", columnDefinition = "NVARCHAR(20) NULL")
	private String phone;

	@Column(name = "createddate")
	private Date createdDate;

	@Column(name = "status")
	private Integer status;

	@Column(name = "otp", columnDefinition = "VARCHAR(10) NULL")
	private String otp;

	@OneToMany(mappedBy = "user")
	private List<Video> videos;

	public User() {
	}

	public User(String email, String userName, String fullName, String password, String avatar, int roleid,
			String phone, Date createdDate, int status, String otp) {
		this.email = email;
		this.userName = userName;
		this.fullName = fullName;
		this.password = password;
		this.avatar = avatar;
		this.roleid = roleid;
		this.phone = phone;
		this.createdDate = createdDate;
		this.status = status;
		this.otp = otp;
	}

	// Getters & Setters
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getAvatar() {
		return avatar;
	}

	public void setAvatar(String avatar) {
		this.avatar = avatar;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getOtp() {
		return otp;
	}

	public void setOtp(String otp) {
		this.otp = otp;
	}

	public List<Video> getVideos() {
		return videos;
	}

	public void setVideos(List<Video> videos) {
		this.videos = videos;
	}

	public Integer getRoleid() {
		return roleid != null ? roleid : 3;
	}

	public void setRoleid(Integer roleid) {
		this.roleid = roleid;
	}

	public Integer getStatus() {
		return status != null ? status : 0;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}
}