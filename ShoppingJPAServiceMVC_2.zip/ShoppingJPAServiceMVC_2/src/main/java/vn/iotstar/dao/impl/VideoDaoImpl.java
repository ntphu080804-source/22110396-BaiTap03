package vn.iotstar.dao.impl;

import java.util.List;
import jakarta.persistence.*;
import vn.iotstar.config.JpaConfig;
import vn.iotstar.dao.IVideoDao;
import vn.iotstar.entity.Video;

public class VideoDaoImpl implements IVideoDao {

	@Override
	public void insert(Video video) {
		EntityManager enma = JpaConfig.getEntityManager();
		EntityTransaction trans = enma.getTransaction();
		try {
			trans.begin();
			enma.persist(video);
			trans.commit();
		} catch (Exception e) {
			if (trans.isActive())
				trans.rollback();
			throw e;
		} finally {
			enma.close();
		}
	}

	@Override
	public void update(Video video) {
		EntityManager enma = JpaConfig.getEntityManager();
		EntityTransaction trans = enma.getTransaction();
		try {
			trans.begin();
			enma.merge(video);
			trans.commit();
		} catch (Exception e) {
			if (trans.isActive())
				trans.rollback();
			throw e;
		} finally {
			enma.close();
		}
	}

	@Override
	public void delete(String videoId) throws Exception {
		EntityManager enma = JpaConfig.getEntityManager();
		EntityTransaction trans = enma.getTransaction();
		try {
			trans.begin();
			Video video = enma.find(Video.class, videoId);
			if (video != null) {
				enma.remove(video);
			} else {
				throw new Exception("Không tìm thấy Video");
			}
			trans.commit();
		} catch (Exception e) {
			if (trans.isActive())
				trans.rollback();
			throw e;
		} finally {
			enma.close();
		}
	}

	@Override
	public Video findById(String videoId) {
		EntityManager enma = JpaConfig.getEntityManager();
		try {
			return enma.find(Video.class, videoId);
		} finally {
			enma.close();
		}
	}

	@Override
	public List<Video> findAll() {
		EntityManager enma = JpaConfig.getEntityManager();
		try {
			return enma.createQuery("SELECT v FROM Video v ORDER BY v.createdDate DESC", Video.class).getResultList();
		} finally {
			enma.close();
		}
	}

	@Override
	public List<Video> findTop10Newest() {
		EntityManager enma = JpaConfig.getEntityManager();
		try {
			TypedQuery<Video> query = enma
					.createQuery("SELECT v FROM Video v WHERE v.active = 1 ORDER BY v.createdDate DESC", Video.class);
			query.setMaxResults(10);
			return query.getResultList();
		} finally {
			enma.close();
		}
	}

	@Override
	public List<Video> findByUserId(int userId, int page, int pageSize) {
		EntityManager enma = JpaConfig.getEntityManager();
		try {
			TypedQuery<Video> query = enma.createQuery(
					"SELECT v FROM Video v WHERE v.user.id = :uid ORDER BY v.createdDate DESC", Video.class);
			query.setParameter("uid", userId);
			query.setFirstResult((page - 1) * pageSize);
			query.setMaxResults(pageSize);
			return query.getResultList();
		} finally {
			enma.close();
		}
	}

	@Override
	public int countByUserId(int userId) {
		EntityManager enma = JpaConfig.getEntityManager();
		try {
			Long count = enma.createQuery("SELECT COUNT(v) FROM Video v WHERE v.user.id = :uid", Long.class)
					.setParameter("uid", userId).getSingleResult();
			return count.intValue();
		} finally {
			enma.close();
		}
	}
}