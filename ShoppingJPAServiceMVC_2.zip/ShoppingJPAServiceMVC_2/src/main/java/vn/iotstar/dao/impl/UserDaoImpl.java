package vn.iotstar.dao.impl;

import jakarta.persistence.*;
import vn.iotstar.config.JpaConfig;
import vn.iotstar.dao.IUserDao;
import vn.iotstar.entity.User;

public class UserDaoImpl implements IUserDao {

	@Override
	public User findByUsername(String username) {
		EntityManager enma = JpaConfig.getEntityManager();
		try {
			TypedQuery<User> query = enma.createQuery("SELECT u FROM User u WHERE u.userName = :username", User.class);
			query.setParameter("username", username);
			return query.getSingleResult();
		} catch (NoResultException e) {
			return null;
		} finally {
			enma.close();
		}
	}

	@Override
	public User findByEmail(String email) {
		EntityManager enma = JpaConfig.getEntityManager();
		try {
			TypedQuery<User> query = enma.createQuery("SELECT u FROM User u WHERE u.email = :email", User.class);
			query.setParameter("email", email);
			return query.getSingleResult();
		} catch (NoResultException e) {
			return null;
		} finally {
			enma.close();
		}
	}

	@Override
	public void insert(User user) {
		EntityManager enma = JpaConfig.getEntityManager();
		EntityTransaction trans = enma.getTransaction();
		try {
			trans.begin();
			enma.persist(user);
			trans.commit();
		} catch (Exception e) {
			if (trans.isActive())
				trans.rollback();
			throw e;
		} finally {
			enma.close();
		}
	}

	@Override
	public void update(User user) {
		EntityManager enma = JpaConfig.getEntityManager();
		EntityTransaction trans = enma.getTransaction();
		try {
			trans.begin();
			enma.merge(user);
			trans.commit();
		} catch (Exception e) {
			if (trans.isActive())
				trans.rollback();
			throw e;
		} finally {
			enma.close();
		}
	}

	@Override
	public boolean checkExistEmail(String email) {
		return findByEmail(email) != null;
	}

	@Override
	public boolean checkExistUsername(String username) {
		return findByUsername(username) != null;
	}

	@Override
	public boolean checkExistPhone(String phone) {
		EntityManager enma = JpaConfig.getEntityManager();
		try {
			Long count = enma.createQuery("SELECT COUNT(u) FROM User u WHERE u.phone = :phone", Long.class)
					.setParameter("phone", phone).getSingleResult();
			return count > 0;
		} finally {
			enma.close();
		}
	}
}