package vn.iotstar.service.impl;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.util.List;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.Part;
import vn.iotstar.dao.ICategoryDao;
import vn.iotstar.dao.IVideoDao;
import vn.iotstar.dao.impl.CategoryDaoImpl;
import vn.iotstar.dao.impl.VideoDaoImpl;
import vn.iotstar.entity.Category;
import vn.iotstar.entity.User;
import vn.iotstar.entity.Video;
import vn.iotstar.service.IVideoService;
import vn.iotstar.util.Constant;

public class VideoServiceImpl implements IVideoService {
	private IVideoDao videoDao = new VideoDaoImpl();
	private ICategoryDao cateDao = new CategoryDaoImpl();

	@Override
	public List<Video> findAll() {
		return videoDao.findAll();
	}

	@Override
	public List<Video> findTop10Newest() {
		return videoDao.findTop10Newest();
	}

	@Override
	public List<Video> findByUserId(int userId, int page, int pageSize) {
		return videoDao.findByUserId(userId, page, pageSize);
	}

	@Override
	public int countByUserId(int userId) {
		return videoDao.countByUserId(userId);
	}

	@Override
	public Video findById(String videoId) {
		return videoDao.findById(videoId);
	}

	@Override
	public Video watchVideo(String videoId) {
		Video v = videoDao.findById(videoId);
		if (v != null) {
			v.setViews(v.getViews() + 1);
			videoDao.update(v);
		}
		return v;
	}

	@Override
	public void delete(String videoId) throws Exception {
		Video v = videoDao.findById(videoId);
		if (v != null) {
			if (v.getPoster() != null && !v.getPoster().startsWith("http")) {
				Files.deleteIfExists(Paths.get(Constant.DIR + "/" + v.getPoster()));
			}
			if (v.getVideoUrl() != null && !v.getVideoUrl().startsWith("http")) {
				Files.deleteIfExists(Paths.get(Constant.DIR + "/" + v.getVideoUrl()));
			}
			videoDao.delete(videoId);
		}
	}

	private String saveUploadFile(Part part, String prefix) throws Exception {
		if (part != null && part.getSize() > 0) {
			File uploadDir = new File(Constant.DIR);
			if (!uploadDir.exists())
				uploadDir.mkdirs();

			String submittedName = Paths.get(part.getSubmittedFileName()).getFileName().toString();
			String ext = submittedName.substring(submittedName.lastIndexOf("."));
			String savedName = prefix + "_" + System.currentTimeMillis() + ext;
			part.write(Constant.DIR + File.separator + savedName);
			return savedName;
		}
		return null;
	}

	@Override
	public void processInsert(HttpServletRequest req, User currentUser) {
		try {
			String videoId = req.getParameter("videoId");
			String title = req.getParameter("title");
			String description = req.getParameter("description");
			int active = Integer.parseInt(req.getParameter("active"));
			int categoryId = Integer.parseInt(req.getParameter("categoryId"));
			String videoLink = req.getParameter("videoLink");

			Category cate = cateDao.findById(categoryId);

			Video v = new Video();
			v.setVideoId(videoId);
			v.setTitle(title);
			v.setDescription(description);
			v.setActive(active);
			v.setViews(0);
			v.setCreatedDate(new Timestamp(System.currentTimeMillis()));
			v.setCategory(cate);
			v.setUser(currentUser);

			// Upload Poster
			String posterFile = saveUploadFile(req.getPart("posterFile"), "poster");
			v.setPoster(posterFile != null ? posterFile : "https://via.placeholder.com/320x180?text=No+Poster");

			// Upload Video MP4 hoặc dùng Link
			String videoFile = saveUploadFile(req.getPart("videoFile"), "vid");
			if (videoFile != null) {
				v.setVideoUrl(videoFile);
			} else if (videoLink != null && !videoLink.trim().isEmpty()) {
				v.setVideoUrl(videoLink.trim());
			}

			videoDao.insert(v);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void processUpdate(HttpServletRequest req) {
		try {
			String videoId = req.getParameter("videoId");
			String title = req.getParameter("title");
			String description = req.getParameter("description");
			int active = Integer.parseInt(req.getParameter("active"));
			int categoryId = Integer.parseInt(req.getParameter("categoryId"));
			String videoLink = req.getParameter("videoLink");

			Video v = videoDao.findById(videoId);
			if (v == null)
				return;

			v.setTitle(title);
			v.setDescription(description);
			v.setActive(active);
			v.setCategory(cateDao.findById(categoryId));

			String newPoster = saveUploadFile(req.getPart("posterFile"), "poster");
			if (newPoster != null) {
				if (v.getPoster() != null && !v.getPoster().startsWith("http")) {
					Files.deleteIfExists(Paths.get(Constant.DIR + "/" + v.getPoster()));
				}
				v.setPoster(newPoster);
			}

			String newVideo = saveUploadFile(req.getPart("videoFile"), "vid");
			if (newVideo != null) {
				if (v.getVideoUrl() != null && !v.getVideoUrl().startsWith("http")) {
					Files.deleteIfExists(Paths.get(Constant.DIR + "/" + v.getVideoUrl()));
				}
				v.setVideoUrl(newVideo);
			} else if (videoLink != null && !videoLink.trim().isEmpty()) {
				v.setVideoUrl(videoLink.trim());
			}

			videoDao.update(v);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}