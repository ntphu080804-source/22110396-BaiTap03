package vn.iotstar.service.impl;

import java.sql.Date;
import jakarta.servlet.http.*;
import vn.iotstar.dao.IUserDao;
import vn.iotstar.dao.impl.UserDaoImpl;
import vn.iotstar.entity.User;
import vn.iotstar.service.IUserService;
import vn.iotstar.util.Constant;
import vn.iotstar.util.EmailUtil;
import vn.iotstar.util.PasswordUtil;

public class UserServiceImpl implements IUserService {
	private IUserDao userDao = new UserDaoImpl();

	@Override
	public String processLogin(String username, String password, boolean isRememberMe, HttpServletRequest req,
			HttpServletResponse resp) {
		if (username == null || username.trim().isEmpty() || password == null || password.trim().isEmpty()) {
			return "Tài khoản hoặc mật khẩu không được để trống!";
		}
		User user = userDao.findByUsername(username.trim());
		if (user == null || !PasswordUtil.checkPassword(password, user.getPassword())) {
			return "Tài khoản hoặc mật khẩu không chính xác!";
		}
		if (user.getStatus() == 0) {
			return "Tài khoản chưa được kích hoạt OTP qua Email!";
		}

		HttpSession session = req.getSession(true);
		session.setAttribute("account", user);

		Cookie cookie = new Cookie(Constant.COOKIE_REMEMBER, isRememberMe ? username.trim() : "");
		cookie.setMaxAge(isRememberMe ? 30 * 60 : 0);
		cookie.setPath("/");
		resp.addCookie(cookie);
		return null;
	}

	@Override
	public String checkAutoLogin(HttpServletRequest req) {
		HttpSession session = req.getSession(false);
		if (session != null && session.getAttribute("account") != null) {
			return "/waiting";
		}
		Cookie[] cookies = req.getCookies();
		if (cookies != null) {
			for (Cookie c : cookies) {
				if (Constant.COOKIE_REMEMBER.equals(c.getName()) && !c.getValue().isEmpty()) {
					User u = userDao.findByUsername(c.getValue());
					if (u != null && u.getStatus() == 1) {
						req.getSession(true).setAttribute("account", u);
						return "/waiting";
					}
				}
			}
		}
		return null;
	}

	@Override
	public String getRedirectUrlByRole(User user, String contextPath) {
		if (user == null)
			return contextPath + "/login";
		if (user.getRoleid() == 1)
			return contextPath + "/admin/categories";
		return contextPath + "/home";
	}

	@Override
	public String registerWithOTP(String username, String password, String email, String fullname, String phone) {
		if (username == null || username.trim().isEmpty() || password == null || password.trim().isEmpty()
				|| email == null || email.trim().isEmpty()) {
			return "Vui lòng nhập đầy đủ Username, Password và Email!";
		}
		if (userDao.checkExistUsername(username.trim()))
			return "Tên đăng nhập đã tồn tại!";
		if (userDao.checkExistEmail(email.trim()))
			return "Email đã được đăng ký!";

		String otp = PasswordUtil.generateOTP();
		String hashedPass = PasswordUtil.hashPassword(password);
		Date now = new Date(System.currentTimeMillis());

		// status = 0 (chưa kích hoạt)
		User newUser = new User(email.trim(), username.trim(), fullname, hashedPass, null, 3, phone, now, 0, otp);
		userDao.insert(newUser);

		boolean sent = EmailUtil.sendOTP(email.trim(), "Mã OTP kích hoạt tài khoản", otp);
		if (!sent) {
			return "Tạo tài khoản thành công nhưng gửi Email thất bại. Kiểm tra lại cấu hình SMTP!";
		}
		return null;
	}

	@Override
	public boolean verifyRegisterOTP(String email, String otpInput) {
		User u = userDao.findByEmail(email);
		if (u != null && u.getOtp() != null && u.getOtp().equals(otpInput.trim())) {
			u.setStatus(1);
			u.setOtp(null);
			userDao.update(u);
			return true;
		}
		return false;
	}

	@Override
	public String sendForgotPasswordOTP(String email) {
		if (email == null || email.trim().isEmpty())
			return "Vui lòng nhập Email!";
		User u = userDao.findByEmail(email.trim());
		if (u == null)
			return "Email không tồn tại trong hệ thống!";

		String otp = PasswordUtil.generateOTP();
		u.setOtp(otp);
		userDao.update(u);

		boolean sent = EmailUtil.sendOTP(email.trim(), "Mã OTP khôi phục mật khẩu", otp);
		return sent ? null : "Gửi Email thất bại. Kiểm tra cấu hình SMTP!";
	}

	@Override
	public String resetPasswordWithOTP(String email, String otpInput, String newPassword) {
		if (newPassword == null || newPassword.trim().isEmpty())
			return "Mật khẩu mới không được rỗng!";
		User u = userDao.findByEmail(email);
		if (u == null)
			return "Tài khoản không tồn tại!";
		if (u.getOtp() == null || !u.getOtp().equals(otpInput.trim())) {
			return "Mã OTP không chính xác!";
		}
		u.setPassword(PasswordUtil.hashPassword(newPassword));
		u.setOtp(null);
		u.setStatus(1);
		userDao.update(u);
		return null;
	}
}