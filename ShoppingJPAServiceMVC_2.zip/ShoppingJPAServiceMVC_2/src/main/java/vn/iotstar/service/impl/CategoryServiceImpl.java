package vn.iotstar.service.impl;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.Part;
import vn.iotstar.dao.ICategoryDao;
import vn.iotstar.dao.impl.CategoryDaoImpl;
import vn.iotstar.entity.Category;
import vn.iotstar.service.ICategoryService;
import vn.iotstar.util.Constant;

public class CategoryServiceImpl implements ICategoryService {
	private ICategoryDao cateDao = new CategoryDaoImpl();

	@Override
	public List<Category> findAll() {
		return cateDao.findAll();
	}

	@Override
	public Category findById(int id) {
		return cateDao.findById(id);
	}

	@Override
	public List<Category> searchByName(String keyword) {
		return cateDao.searchByName(keyword);
	}

	@Override
	public void insert(Category category) {
		if (this.findByCategoryname(category.getCategoryname()) == null) {
			cateDao.insert(category);
		}
	}

	@Override
	public void update(Category category) {
		if (this.findById(category.getCategoryid()) != null) {
			cateDao.update(category);
		}
	}

	@Override
	public void delete(int id) throws Exception {
		Category cate = this.findById(id);
		if (cate != null && cate.getImages() != null && !cate.getImages().startsWith("http")) {
			Path oldPath = Paths.get(Constant.DIR + "/" + cate.getImages());
			Files.deleteIfExists(oldPath);
		}
		cateDao.delete(id);
	}

	@Override
	public int count() {
		return cateDao.count();
	}

	@Override
	public List<Category> findAll(int page, int pagesize) {
		return cateDao.findAll(page, pagesize);
	}

	@Override
	public Category findByCategoryname(String name) {
		return cateDao.findByCategoryname(name);
	}

	@Override
	public void processInsert(HttpServletRequest req) {
		try {
			String categoryname = req.getParameter("categoryname");
			int status = Integer.parseInt(req.getParameter("status"));
			String images = req.getParameter("images");

			Category category = new Category();
			category.setCategoryname(categoryname);
			category.setStatus(status);

			File uploadDir = new File(Constant.DIR);
			if (!uploadDir.exists())
				uploadDir.mkdirs();

			Part part = req.getPart("images1");
			if (part != null && part.getSize() > 0) {
				String filename = Paths.get(part.getSubmittedFileName()).getFileName().toString();
				String ext = filename.substring(filename.lastIndexOf(".") + 1);
				String fname = System.currentTimeMillis() + "." + ext;
				part.write(Constant.DIR + "/" + fname);
				category.setImages(fname);
			} else if (images != null && !images.trim().isEmpty()) {
				category.setImages(images.trim());
			} else {
				category.setImages("avatar.png");
			}
			this.insert(category);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void processUpdate(HttpServletRequest req) {
		try {
			int categoryid = Integer.parseInt(req.getParameter("categoryid"));
			String categoryname = req.getParameter("categoryname");
			int status = Integer.parseInt(req.getParameter("status"));
			String images = req.getParameter("images");

			Category category = this.findById(categoryid);
			String fileold = category.getImages();
			category.setCategoryname(categoryname);
			category.setStatus(status);

			File uploadDir = new File(Constant.DIR);
			if (!uploadDir.exists())
				uploadDir.mkdirs();

			Part part = req.getPart("images1");
			if (part != null && part.getSize() > 0) {
				if (fileold != null && !fileold.startsWith("http")) {
					Files.deleteIfExists(Paths.get(Constant.DIR + "/" + fileold));
				}
				String filename = Paths.get(part.getSubmittedFileName()).getFileName().toString();
				String ext = filename.substring(filename.lastIndexOf(".") + 1);
				String fname = System.currentTimeMillis() + "." + ext;
				part.write(Constant.DIR + "/" + fname);
				category.setImages(fname);
			} else if (images != null && !images.trim().isEmpty()) {
				category.setImages(images.trim());
			} else {
				category.setImages(fileold);
			}
			this.update(category);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}