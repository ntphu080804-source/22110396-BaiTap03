package vn.iotstar.controller;

import java.io.IOException;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import vn.iotstar.entity.User;
import vn.iotstar.entity.Video;
import vn.iotstar.service.ICategoryService;
import vn.iotstar.service.IVideoService;
import vn.iotstar.service.impl.CategoryServiceImpl;
import vn.iotstar.service.impl.VideoServiceImpl;

@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2, // 2MB
		maxFileSize = 1024 * 1024 * 50, // 50MB
		maxRequestSize = 1024 * 1024 * 100 // 100MB
)
@WebServlet(urlPatterns = { "/video", "/video/detail", "/user/video/add", "/user/video/insert" })
public class VideoController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private IVideoService videoService = new VideoServiceImpl();
	private ICategoryService cateService = new CategoryServiceImpl();

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String url = req.getRequestURI();
		HttpSession session = req.getSession(false);
		User currentUser = (session != null) ? (User) session.getAttribute("account") : null;

		if (url.contains("/video/detail")) {
			String id = req.getParameter("id");
			Video v = videoService.watchVideo(id);
			req.setAttribute("video", v);
			req.getRequestDispatcher("/views/video-detail.jsp").forward(req, resp);
			return;
		}

		// Các chức năng bên dưới bắt buộc đăng nhập
		if (currentUser == null) {
			resp.sendRedirect(req.getContextPath() + "/login");
			return;
		}

		if (url.endsWith("/video")) {
			int page = 1;
			int pageSize = 6;
			if (req.getParameter("page") != null) {
				page = Integer.parseInt(req.getParameter("page"));
			}
			int totalItems = videoService.countByUserId(currentUser.getId());
			int totalPages = (int) Math.ceil((double) totalItems / pageSize);

			List<Video> userVideos = videoService.findByUserId(currentUser.getId(), page, pageSize);
			req.setAttribute("videos", userVideos);
			req.setAttribute("currentPage", page);
			req.setAttribute("totalPages", totalPages);
			req.getRequestDispatcher("/views/video-list-user.jsp").forward(req, resp);
		} else if (url.contains("/user/video/add")) {
			req.setAttribute("categories", cateService.findAll());
			req.getRequestDispatcher("/views/user-video-add.jsp").forward(req, resp);
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session = req.getSession(false);
		User currentUser = (session != null) ? (User) session.getAttribute("account") : null;
		if (currentUser == null) {
			resp.sendRedirect(req.getContextPath() + "/login");
			return;
		}

		req.setCharacterEncoding("UTF-8");
		String url = req.getRequestURI();

		if (url.contains("/user/video/insert")) {
			videoService.processInsert(req, currentUser);
			resp.sendRedirect(req.getContextPath() + "/video");
		}
	}
}