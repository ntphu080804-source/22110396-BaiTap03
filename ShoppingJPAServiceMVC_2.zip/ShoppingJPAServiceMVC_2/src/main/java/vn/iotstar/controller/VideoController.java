package vn.iotstar.controller;

import java.io.IOException;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import vn.iotstar.entity.User;
import vn.iotstar.entity.Video;
import vn.iotstar.service.IVideoService;
import vn.iotstar.service.impl.VideoServiceImpl;

@WebServlet(urlPatterns = { "/video", "/video/detail" })
public class VideoController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private IVideoService videoService = new VideoServiceImpl();

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String url = req.getRequestURI();
		HttpSession session = req.getSession(false);
		User currentUser = (session != null) ? (User) session.getAttribute("account") : null;

		if (url.endsWith("/video")) {
			if (currentUser == null) {
				resp.sendRedirect(req.getContextPath() + "/login");
				return;
			}
			int page = 1;
			int pageSize = 6;
			if (req.getParameter("page") != null) {
				page = Integer.parseInt(req.getParameter("page"));
			}
			int totalItems = videoService.countByUserId(currentUser.getId());
			int totalPages = (int) Math.ceil((double) totalItems / pageSize);

			List<Video> userVideos = videoService.findByUserId(currentUser.getId(), page, pageSize);
			req.setAttribute("videos", userVideos);
			req.setAttribute("currentPage", page);
			req.setAttribute("totalPages", totalPages);
			req.getRequestDispatcher("/views/video-list-user.jsp").forward(req, resp);
		} else if (url.contains("/video/detail")) {
			String id = req.getParameter("id");
			Video v = videoService.watchVideo(id);
			req.setAttribute("video", v);
			req.getRequestDispatcher("/views/video-detail.jsp").forward(req, resp);
		}
	}
}