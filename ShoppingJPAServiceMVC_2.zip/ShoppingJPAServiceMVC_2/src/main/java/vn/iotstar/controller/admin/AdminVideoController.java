package vn.iotstar.controller.admin;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import vn.iotstar.entity.User;
import vn.iotstar.service.ICategoryService;
import vn.iotstar.service.IVideoService;
import vn.iotstar.service.impl.CategoryServiceImpl;
import vn.iotstar.service.impl.VideoServiceImpl;

@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2, // 2MB
		maxFileSize = 1024 * 1024 * 50, // 50MB
		maxRequestSize = 1024 * 1024 * 100 // 100MB
)
@WebServlet(urlPatterns = { "/admin/videos", "/admin/video/add", "/admin/video/insert", "/admin/video/edit",
		"/admin/video/update", "/admin/video/delete" })
public class AdminVideoController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private IVideoService videoService = new VideoServiceImpl();
	private ICategoryService cateService = new CategoryServiceImpl();

	private User getAdminUser(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		HttpSession session = req.getSession(false);
		User u = (session != null) ? (User) session.getAttribute("account") : null;
		if (u == null || u.getRoleid() != 1) {
			resp.sendRedirect(req.getContextPath() + "/login");
			return null;
		}
		return u;
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		if (getAdminUser(req, resp) == null)
			return;

		String url = req.getRequestURI();
		if (url.contains("/admin/videos")) {
			req.setAttribute("videos", videoService.findAll());
			req.getRequestDispatcher("/views/admin/video/video-list.jsp").forward(req, resp);
		} else if (url.contains("/admin/video/add")) {
			req.setAttribute("categories", cateService.findAll());
			req.getRequestDispatcher("/views/admin/video/video-add.jsp").forward(req, resp);
		} else if (url.contains("/admin/video/edit")) {
			String id = req.getParameter("id");
			req.setAttribute("video", videoService.findById(id));
			req.setAttribute("categories", cateService.findAll());
			req.getRequestDispatcher("/views/admin/video/video-edit.jsp").forward(req, resp);
		} else if (url.contains("/admin/video/delete")) {
			try {
				videoService.delete(req.getParameter("id"));
			} catch (Exception e) {
				e.printStackTrace();
			}
			resp.sendRedirect(req.getContextPath() + "/admin/videos");
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		User admin = getAdminUser(req, resp);
		if (admin == null)
			return;

		req.setCharacterEncoding("UTF-8");
		String url = req.getRequestURI();

		if (url.contains("/admin/video/insert")) {
			videoService.processInsert(req, admin);
			resp.sendRedirect(req.getContextPath() + "/admin/videos");
		} else if (url.contains("/admin/video/update")) {
			videoService.processUpdate(req);
			resp.sendRedirect(req.getContextPath() + "/admin/videos");
		}
	}
}